<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="0;url=index.php">
<title>School Management System</title>
<script language="javascript">
    window.location.href = "sms/view/login.php"
</script>
</head>
<body>
Go to <a href="index.php">index.php</a>
</body>
</html>